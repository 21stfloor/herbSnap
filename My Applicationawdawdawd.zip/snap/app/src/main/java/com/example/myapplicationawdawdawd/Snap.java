package com.example.myapplicationawdawdawd;

import static com.example.myapplicationawdawdawd.R.id.imageLogo;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Snap extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAMERA = 1;

    private void startCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAMERA);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snap);

        ImageView imageAccount = findViewById(R.id.imageAccount);
        imageAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent imageAccount = new Intent(Snap.this, Mygarden.class);
                startActivity(imageAccount);
            }
        });

        ImageButton snaplogo = findViewById(R.id.snaplogo);
        snaplogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startCamera();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

      if (requestCode == REQUEST_IMAGE_CAMERA && resultCode == RESULT_OK) {
          Bundle extras = data.getExtras();
          Bitmap imageBitmap = (Bitmap) extras.get("data");

          ImageView imageView;
      }
    }

}